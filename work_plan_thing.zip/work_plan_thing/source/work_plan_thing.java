import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class work_plan_thing extends PApplet {



int scrollbarSize = 30;
int taskBorder = 12;
int taskSpacing = 12;
int taskWidth, taskHeight;
int topBarHeightL = 90, topBarHeightR = 160;
int taskScreenWidth, taskScreenHeight, jobScreenWidth, jobScreenHeight;
int addTaskButtonSize;

float tint = 1;

UI taskScreen;
TaskList tasks;
Scrollbar bar;
Text taskListTitle;

UI jobScreen;
JobList jobs;
Scrollbar bar2;
Text jobListTitle;

Button workflowBackground;
TextButton startWork, pause, complete;
Timer timer;
Text maxTime, ofText;
boolean working = false;

AddTaskWindow addTaskWindow;
RightClickWindow rightClickWindow;
CreateJobWindow createJobWindow;
AddTimeWindow addTimeWindow;
AddBreakWindow addBreakWindow;
boolean windowOpen = false, prevWindowOpen = false;

SoundFile alarm;

public void settings() {
  size(660, 800);
}

public void setup() {
  frameRate(60);
  surface.setTitle("The other Task Manager");
  
  alarm = new SoundFile(this, "alarm.wav");
  
  taskWidth = width/2 - scrollbarSize - taskBorder*2;
  taskHeight = (int)(taskWidth / 2.5f);
  println(taskWidth + " " + taskHeight);
  taskScreenHeight = height - topBarHeightL;
  taskScreenWidth = width/2 - scrollbarSize;
  jobScreenHeight = height - topBarHeightR;
  jobScreenWidth = width/2 - scrollbarSize;
  addTaskButtonSize = (int)(taskHeight * 0.5f);
  
  initFonts();
  
  
  taskScreen = new UI(0, topBarHeightL);
  bar = new Scrollbar(taskScreenWidth - 1, taskBorder, scrollbarSize, taskScreenHeight - taskBorder*2, taskScreen);
  
  tasks = new TaskList("Task List 0", taskScreen);
  tasks.setTargetPosition(taskBorder, taskBorder);
  tasks.snapToPosition();
  
  taskListTitle = new Text(width/4, taskBorder + 48, "Task List", titleFont);
  
  
  jobScreen = new UI(width/2, topBarHeightR);
  bar2 = new Scrollbar(jobScreenWidth + 1, taskBorder, scrollbarSize, jobScreenHeight - taskBorder*2, jobScreen);
  
  jobs = new JobList("Task List 0", jobScreen);
  jobs.setTargetPosition(taskBorder, taskBorder);
  jobs.snapToPosition();
  
  jobListTitle = new Text(width * (3.0f/4), taskBorder + 48, "Workflow", titleFont);
  
  int bw = width/2 - taskBorder*4;
  int bh = topBarHeightR/2 - (int)(taskBorder*1.5f);
  startWork = new TextButton(width * (3.0f/4) - bw/2, topBarHeightR - bh - taskBorder, bw, bh, "start");
  timer = new Timer(width/2 + taskBorder + 10, topBarHeightR - 50, false, new Time(0, 0, 0));
  maxTime = new Text(width/2 + taskBorder + 39, topBarHeightR - 17, "00:00", timerFont);
  ofText = new Text(width/2 + taskBorder + 22, topBarHeightR - 20, "of", buttonFont);
  maxTime.setAlign(LEFT);
  timer.align = LEFT;
  workflowBackground = new Button(width/2, 0, width/2, topBarHeightR);
  int bw2 = 90;
  int bh2 = 28;
  complete = new TextButton(width - taskBorder*2 - bw2, topBarHeightR - taskBorder - bh2, bw2, bh2, "next");
  pause = new TextButton(width - taskBorder*2 - bw2, topBarHeightR - taskBorder - 6 - bh2*2, bw2, bh2, "pause");
  
  
  addTaskWindow = new AddTaskWindow();
  rightClickWindow = new RightClickWindow();
  createJobWindow = new CreateJobWindow();
  addTimeWindow = new AddTimeWindow();
  addBreakWindow = new AddBreakWindow();
}

public void draw() {
  TimerController.update();
  
  
  tint = 1;
  prevWindowOpen = windowOpen;
  windowOpen = false;
  addTaskWindow.update();
  rightClickWindow.update();
  createJobWindow.update();
  addTimeWindow.update();
  addBreakWindow.update();
  if(addTaskWindow.open || rightClickWindow.open || createJobWindow.open || addTimeWindow.open || addBreakWindow.open) {
    tint = 0.5f;
    windowOpen = true;
  }
  
  background(100 * tint);
  
  bar.update();
  bar.display();
  
  int borderSize = 4;
  noStroke();
  fill(100 * tint);
  if(!windowOpen && tasks.selectedTask != -1 && mouseX > width/2) {
    fill(100 * 1.3f);
  }
  rect(width/2, 0, width/2, height);
  fill(0);
  rect(width/2 - (int)(floor((float)borderSize/2.0f)), 0, borderSize, height);
  
  tasks.targetx = taskBorder;
  tasks.update();
  tasks.display();
  
  
  stroke(40 * tint);
  strokeWeight(4);
  strokeJoin(BEVEL);
  fill(235 * tint);
  
  float w = width/2 - taskBorder*2;
  rect(width/4 - w/2, taskBorder, w, topBarHeightL - taskBorder);
  
  
  taskListTitle.update();
  taskListTitle.display();
  
  
  if(!windowOpen && tasks.selectedTask != -1 && mouseX > width/2) {
    tint = 1.3f;
  }
  
  bar2.update();
  bar2.display();
  
  workflowBackground.update();
  if(!windowOpen && !prevWindowOpen && workflowBackground.action && mouseButton == RIGHT) {
    rightClickWindow.open(3, 0);
    windowOpen = true;
  }
  jobs.targetx = taskBorder;
  jobs.update();
  jobs.display();
  
  stroke(40 * tint);
  strokeWeight(4);
  strokeJoin(BEVEL);
  fill(235 * tint);
  rect(width*(3.0f/4) - w/2, taskBorder, w, topBarHeightR - taskBorder);
  
  jobListTitle.update();
  jobListTitle.display();
  
  if(!working) {
    startWork.update();
    
    if(!windowOpen && startWork.action && jobs.jobs.size() > 0) {
      working = true;
      timer.active = true;
      jobs.beginWork();
    } else {
      startWork.display();
    }
  } else {
    startWork.update();
    
    timer.update();
    timer.display();
    maxTime.update();
    maxTime.display();
    ofText.update();
    ofText.display();
    pause.update();
    pause.display();
    complete.update();
    complete.display();
    
    if(pause.action) {
      alarm.stop();
      if(pause.text.text.equals("pause")) {
        timer.active = false;
        pause.text.text = "resume";
      } else if(pause.text.text.equals("add")) {
        addTimeWindow.open(jobs.jobs.get(jobs.currentJob));
      } else {
        timer.active = true;
        pause.text.text = "pause";
      }
    } else if(complete.action) {
      alarm.stop();
      jobs.nextJob();
    }
  }
  
  
  tint = 1;
  
  addTaskWindow.display();
  rightClickWindow.display();
  createJobWindow.display();
  addTimeWindow.display();
  addBreakWindow.display();
}

public void keyPressed() {
  if(addTaskWindow.open)
    addTaskWindow.pressKey();
  if(createJobWindow.open)
    createJobWindow.pressKey();
}

public void mouseWheel(MouseEvent event) {
  float e = event.getCount();
  
  if(!windowOpen) {
    if(mouseX < width/2)
      bar.moveSlider(e / 16);
    else
      bar2.moveSlider(e / 16);
  }
}
class Task extends UI {
  float moveSpeed = 0.1f;
  
  float targetx, targety;
  String title;
  //Timer timer;
  //Timer maxTime;
  //Button complete, addTime, pause;
  Button background;
  ProgressBar completion;
  
  boolean completed = false;
  
  UI[] elements;
  
  public Task(String t, UI superUI) {
    super(0, 0);
    
    title = t;
    this.superUI = superUI;
    
    background = new Button(0, 0, taskWidth, taskHeight, this);
    
    Text titleText = new Text(taskWidth/2, 0, title, taskFont, this);
    titleText.setAlign(CENTER, TOP);
    
    /*Text ofText = new Text(26, taskHeight - 23, "of", buttonFont, this);
    timer = new Timer(10, taskHeight - 60, true, new Time(0, 0, 0), this);
    maxTime = new Timer(45, taskHeight - 20, false, max, this);
    
    int buttonHeight = 25, buttonWidth = 120;
    complete = new TextButton(taskWidth - buttonWidth - 10, taskHeight - 10 - buttonHeight*1, buttonWidth, buttonHeight, "Complete", this);
    addTime = new TextButton(taskWidth - buttonWidth - 10, taskHeight - 15 - buttonHeight*2, buttonWidth, buttonHeight, "Add Time", this);
    pause = new TextButton(taskWidth - buttonWidth - 10, taskHeight - 20 - buttonHeight*3, buttonWidth, buttonHeight, "Pause", this);*/
    
    int progressBarHeight = 25;
    completion = new ProgressBar(10, taskHeight - 10 - progressBarHeight, taskWidth - 20, progressBarHeight, this);
    
    elements = new UI[] {completion, titleText};
  }
  
  public void setTargetPosition(float x, float y) {
    targetx = x;
    targety = y;
  }
  
  public void snapToPosition() {
    xpos = targetx;
    ypos = targety;
  }
  
  public void update() {
    xpos += (targetx - xpos) * moveSpeed;
    ypos += (targety - ypos) * moveSpeed;
    
    background.update();
    for(UI element: elements) {
      element.update();
    }
    
    if(completion.percentage == 100) {
      completed = true;
    } else {
      completed = false;
    }
  }
  
  public void display() {
    float superx = 0, supery = 0;
    if(superUI != null) {
      superx = superUI.getXPos();
      supery = superUI.getYPos();
    }
    
    float prevTint = tint;
    if(completed) {
      tint *= 0.6f;
    }
    
    background.display();
    
    stroke(40 * tint);
    strokeWeight(4);
    strokeJoin(BEVEL);
    
    fill(235 * tint);
    rect(xpos + superx, ypos + supery, taskWidth, taskHeight);
    
    for(UI element: elements) {
      element.display();
    }
    
    tint = prevTint;
  }
}



class TaskList extends UI {
  ArrayList<Task> tasks;
  TextButton addTaskButton;
  String title;
  float scrollAmount;
  
  float targetx, targety;
  float moveSpeed = 0.2f;
  
  int selectedTask = -1;
  
  public TaskList(String title, UI superUI) {
    super(0, 0);
    
    this.title = title;
    this.superUI = superUI;
    
    addTaskButton = new TextButton(taskWidth/2 + taskSpacing/1 - addTaskButtonSize/2, 0, addTaskButtonSize, addTaskButtonSize, "+", this);
    
    tasks = new ArrayList<Task>();
    
    
    updateTasks();
  }
  
  public void updateTasks() {
    for(int i = 0; i < tasks.size(); i++) {
      if(i != selectedTask) {
        Task t = tasks.get(i);
      
        t.setTargetPosition(0, i * (taskHeight + taskSpacing) + taskBorder);
        t.snapToPosition();
      }
    }
  }
  
  public void setTargetPosition(float x, float y) {
    targetx = x;
    targety = y;
  }
  
  public void snapToPosition() {
    xpos = targetx;
    ypos = targety;
  }
  
  public void update() {
    targety = -bar.scrollValue * max(0, addTaskButtonSize + taskSpacing + tasks.size() * (taskHeight + taskSpacing) + taskBorder*2 - taskSpacing - taskScreenHeight);
    
    xpos += (targetx - xpos) * moveSpeed;
    ypos += (targety - ypos) * moveSpeed;
    
    addTaskButton.ypos = (taskSpacing + taskHeight) * tasks.size() + taskSpacing;
    addTaskButton.update();
    if(addTaskButton.action && !windowOpen && !prevWindowOpen) {
      addTaskWindow.open = true;
    }
    
    for(int i = 0; i < tasks.size(); i++) {
      Task t = tasks.get(i);
      
      t.setTargetPosition(0, i * (taskHeight + taskSpacing) + taskBorder);
      
      if(t.background.action && selectedTask == -1 && !windowOpen && !prevWindowOpen) {
        if(mouseButton == LEFT) {
          selectedTask = i;
        } else {
          rightClickWindow.open(0, i);
        }
      }
    }
    
    if(selectedTask != -1 && !(mousePressed && mouseButton == LEFT)) {
      if(mouseX > width/2) {
        createJobWindow.open(selectedTask);
      }
      selectedTask = -1;
    } else if(selectedTask != -1 && (mousePressed && mouseButton == LEFT)) {
      float distance = mouseY - taskHeight/2 - ypos - (selectedTask * (taskHeight + taskSpacing) + taskBorder + topBarHeightL);
      
      if(distance > taskHeight/2 + taskSpacing && selectedTask < tasks.size()-1) {
        tasks.add(selectedTask + 1, tasks.remove(selectedTask));
        selectedTask++;
        distance -= taskHeight + taskSpacing;
      }
      
      if(distance < -taskHeight/2 - taskSpacing && selectedTask > 0) {
        tasks.add(selectedTask - 1, tasks.remove(selectedTask));
        selectedTask--;
        distance += taskHeight + taskSpacing;
      }
      
      tasks.get(selectedTask).targetx = mouseX - taskWidth/2 - taskBorder;
      tasks.get(selectedTask).targety = (selectedTask * (taskHeight + taskSpacing) + taskBorder) + distance;
      tasks.get(selectedTask).snapToPosition();
    }
    
    for(int i = 0; i < tasks.size(); i++) {
      Task t = tasks.get(i);
      
      if(i == selectedTask) {
        t.moveSpeed = 0.3f;
      } else {
        t.moveSpeed = 0.2f;
      }
      
      t.update();
    }
  }
  
  public void display() {
    for(int i = 0; i < tasks.size(); i++) {
      Task t = tasks.get(i);
      
      if(i != selectedTask) {
        t.display();
      }
    }
    if(selectedTask != -1) {
      tasks.get(selectedTask).display();
    }
    
    addTaskButton.display();
  }
}
final int buttonFontSize = 20;
final int titleFontSize = 40;
final int timerFontSize = 30;
final int taskFontSize = 26;
final String fontName = "Arial Black";
final String timerSeparation = ":";

PFont buttonFont;
PFont titleFont;
PFont timerFont;
PFont taskFont;

public void initFonts() {
  buttonFont = createFont(fontName, buttonFontSize, true);
  titleFont = createFont(fontName, titleFontSize, true);
  timerFont = createFont(fontName, timerFontSize, true);
  taskFont = createFont(fontName, taskFontSize, true);
}

class UI {
  float xpos, ypos;
  UI superUI = null;
  
  public UI(float x, float y) {
    xpos = x;
    ypos = y;
  }
  
  public UI(float x, float y, UI superUI) {
    xpos = x;
    ypos = y;
    
    this.superUI = superUI;
  }
  
  public void update() {}
  public void display() {}
  
  public float getXPos() {
    float superx = 0;
    if(superUI != null) {
      superx = superUI.getXPos();
    }
    return xpos + superx;
  }
  
  public float getYPos() {
    float supery = 0;
    if(superUI != null) {
      supery = superUI.getYPos();
    }
    return ypos + supery;
  }
}

class Button extends UI {
  int bwidth, bheight;
  boolean over;
  boolean pressed, prevPressed;
  boolean clickedOff;
  boolean action;
  
  public Button(float x, float y, int w, int h) {
    super(x, y);
    bwidth = w;
    bheight = h;
    
    over = false;
    pressed = false;
  }
  
  public Button(float x, float y, int w, int h, UI superUI) {
    super(x, y);
    bwidth = w;
    bheight = h;
    
    over = false;
    pressed = false;
    
    this.superUI = superUI;
  }
  
  public void update() {
    float superx = 0, supery = 0;
    if(superUI != null) {
      superx = superUI.getXPos();
      supery = superUI.getYPos();
    }
    
    pressed = false;
    
    if(mouseX >= xpos + superx && mouseX <= xpos + superx + bwidth &&
        mouseY >= ypos + supery && mouseY <= ypos + supery + bheight) {
      over = true;
    } else {
      over = false;
    }
    
    if(mousePressed) {
      if(over && !clickedOff) {
        pressed = true;
      } else {
        clickedOff = true;
        pressed = false;
      }
    } else {
      clickedOff = false;
      pressed = false;
    }
    
    action = false;
    if(pressed && !prevPressed && mousePressed) {
      action = true;
    }
    
    prevPressed = pressed;
  }
  
  public void display() {
    float superx = 0, supery = 0;
    if(superUI != null) {
      superx = superUI.getXPos();
      supery = superUI.getYPos();
    }
    
    stroke(40 * tint);
    strokeWeight(2);
    strokeJoin(BEVEL);
    
    if (pressed) {
      fill(140 * tint);
    } else if(over) {
      fill(180 * tint);
    } else {
      fill(200 * tint);
    }
    rect(xpos + superx, ypos + supery, bwidth, bheight);
  }
}

class Text extends UI {
  String text;
  PFont font;
  int align = CENTER;
  int verticalAlign = 0;
  
  int[] tcolor = {0, 0, 0};
  
  public Text(float x, float y, String t, PFont font) {
    super(x, y);
    text = t;
    this.font = font;
  }
  
  public Text(float x, float y, String t, PFont font, UI superUI) {
    super(x, y);
    text = t;
    this.font = font;
    
    this.superUI = superUI;
  }
  
  public void setColor(int[] newcolor) {
    tcolor = newcolor;
  }
  
  public void setAlign(int align) {
    this.align = align;
  }
  
  public void setAlign(int align, int valign) {
    this.align = align;
    verticalAlign = valign;
  }
  
  public void display() {
    float superx = 0, supery = 0;
    if(superUI != null) {
      superx = superUI.getXPos();
      supery = superUI.getYPos();
    }
    
    textFont(font);
    textAlign(align, verticalAlign);
    fill(tcolor[0] * tint, tcolor[1] * tint, tcolor[2] * tint);
    text(text, xpos + superx, ypos + supery + buttonFontSize/4);
  }
}

class TextButton extends Button {
  Text text;
  
  public TextButton(float x, float y, int w, int h, String t) {
    super(x, y, w, h);
    
    text = new Text(w/2, h/2 + 2, t, buttonFont, this);
  }
  
  public TextButton(float x, float y, int w, int h, String t, UI superUI) {
    super(x, y, w, h, superUI);
    
    text = new Text(w/2, h/2 + 2, t, buttonFont, this);
  }
  
  public void display() {
    super.display();
    
    text.display();
  }
}

static class TimerController {
  public static boolean addSecond = false;
  public static int prevSecond = second();
  
  public static void update() {
    addSecond = false;
    
    if(second() != prevSecond) {
      addSecond = true;
      prevSecond = second();
    }
  }
}

class Time {
  int seconds, minutes, hours;
  int totalSeconds;
  
  public Time(int s, int m, int h) {
    seconds = s;
    minutes = m;
    hours = h;
    totalSeconds = seconds + (minutes*60) + (hours * 3600);
  }
  
  public Time(int s) {
    totalSeconds = s;
    
    hours = (int)(floor((float)s / 3600.0f));
    s -= hours * 3600;
    
    minutes = (int)(floor((float)s / 60.0f));
    s -= minutes * 60;
    
    seconds = s;
  }
  
  public void addSecond() {
    totalSeconds++;
    
    seconds++;
    if(seconds == 60) {
      seconds = 0;
      minutes++;
      if(minutes == 60) {
        minutes = 0;
        hours++;
      }
    }
  }
  
  public void addMinute() {
    totalSeconds += 60;
    
    minutes++;
    if(minutes == 60) {
      minutes = 0;
      hours++;
    }
  }
  
  public void addHour() {
    totalSeconds += 3600;
    
    hours++;
  }
  
  public void addTime(int s, int m, int h) {
    for(int i = 0; i < s; i++) {
      addSecond();
    }
    for(int i = 0; i < m; i++) {
      addMinute();
    }
    for(int i = 0; i < h; i++) {
      addHour();
    }
  }
  
  public boolean greaterThan(Time other) {
    return totalSeconds >= other.totalSeconds;
  }
  
  public String toString() {
    String time = "";
    
    if(hours > 0) {
      time += hours + timerSeparation;
      
      if(minutes < 10) {
        time += "0";
      }
    }
    time += minutes + timerSeparation;
    if(seconds < 10) {
      time += "0";
    }
    time += seconds + "";
    
    return time;
  }
}

class Timer extends UI {
  Time t;
  boolean active;
  int align = LEFT;
  
  public Timer(float x, float y, boolean active, Time startTime) {
    super(x, y);
    this.active = active;
    
    t = startTime;
  }
  
  public Timer(float x, float y, boolean active, Time startTime, UI superUI) {
    super(x, y);
    this.active = active;
    
    t = startTime;
    
    this.superUI = superUI;
  }
  
  public void update() {
    if(active && TimerController.addSecond) {
      t.addSecond();
    }
  }
  
  public void display() {
    float superx = 0, supery = 0;
    if(superUI != null) {
      superx = superUI.getXPos();
      supery = superUI.getYPos();
    }
    
    textFont(timerFont);
    textAlign(align);
    fill(0 * tint);
    text(t.toString(), xpos + superx, ypos + supery + buttonFontSize/4);
  }
}

class Scrollbar extends UI {
  int swidth, sheight;
  int sliderPosition = 0;
  float scrollValue = 0;
  
  boolean over, pressed, prevPressed;
  
  public Scrollbar(int x, int y, int w, int h) {
    super(x, y);
    swidth = w;
    sheight = h;
  }
  
  public Scrollbar(int x, int y, int w, int h, UI superUI) {
    super(x, y);
    swidth = w;
    sheight = h;
    
    this.superUI = superUI;
  }
  
  public void update() {
    float superx = 0, supery = 0;
    if(superUI != null) {
      superx = superUI.getXPos();
      supery = superUI.getYPos();
    }
    
    if(mouseX >= xpos + superx && mouseX <= xpos + superx + swidth &&
        mouseY >= ypos + sliderPosition + supery && mouseY <= ypos + sliderPosition + supery + swidth) {
      over = true;
    } else {
      over = false;
    }
    
    if((mousePressed && mouseButton == LEFT)) {
      if(over || prevPressed) {
        pressed = true;
      } else {
        pressed = false;
      }
    } else {
      pressed = false;
    }
    
    prevPressed = pressed;
    
    
    if(pressed) {
      sliderPosition += 1 * (mouseY - (ypos + supery) - swidth/2 - sliderPosition);
      sliderPosition = clamp(sliderPosition, 0, sheight - swidth);
      scrollValue = (float)sliderPosition / (float)(sheight - swidth);
    }
  }
  
  public void moveSlider(float pct) {
    sliderPosition += pct * sheight;
    sliderPosition = clamp(sliderPosition, 0, sheight - swidth);
    scrollValue = (float)sliderPosition / (float)(sheight - swidth);
  }
  
  public int clamp(int a, int b, int c) {
    return min(max(a, b), c);
  }
  
  public void display() {
    float superx = 0, supery = 0;
    if(superUI != null) {
      superx = superUI.getXPos();
      supery = superUI.getYPos();
    }
    
    stroke(40 * tint);
    strokeWeight(3);
    strokeJoin(BEVEL);
    fill(200 * tint);
    rect(xpos + superx, ypos + supery, swidth + 0, sheight);
    
    noStroke();
    int sliderBorder = 2;
    
    if(over || pressed) {
      fill(120 * tint);
    } else {
      fill(150 * tint);
    }
    rect(xpos + superx + sliderBorder, ypos + supery + sliderPosition + sliderBorder + 0, swidth - sliderBorder*2 + 1, swidth - sliderBorder*2 + 1);
  }
}

class ProgressBar extends UI {
  float bwidth, bheight;
  
  float percentage;
  float targetPercentage;
  float speed = 0.12f;
  Text percentageText;
  
  public ProgressBar(float x, float y, float w, float h) {
    super(x, y);
    bwidth = w;
    bheight = h;
    percentage = 0;
    targetPercentage = 0;
    
    percentageText = new Text(0, -10, "placeholder text", buttonFont, this);
    percentageText.setAlign(LEFT);
    setProgress(0);
  }
  
  public ProgressBar(float x, float y, float w, float h, UI superUI) {
    super(x, y);
    bwidth = w;
    bheight = h;
    percentage = 0;
    targetPercentage = 0;
    
    this.superUI = superUI;
    
    percentageText = new Text(0, -10, "placeholder text", buttonFont, this);
    percentageText.setAlign(LEFT);
    setProgress(0);
  }
  
  public void setProgress(float p) {
    targetPercentage = p;
  }
  
  public void addProgress(float p) {
    targetPercentage += p;
    targetPercentage = min(100, targetPercentage);
  }
  
  public void update() {
    percentage += (targetPercentage - percentage) * speed;
    
    if(abs(targetPercentage - percentage) < 0.2f) {
      percentage = targetPercentage;
    }
    
    percentageText.text = ((float)((int)floor(percentage * 10)) / 10) + "%";
  }
  
  public void display() {
    float superx = 0, supery = 0;
    if(superUI != null) {
      superx = superUI.getXPos();
      supery = superUI.getYPos();
    }
    
    noStroke();
    fill(200 * tint);
    rect(xpos + superx, ypos + supery, bwidth, bheight);
    
    noStroke();
    fill(160 * tint, 160 * tint, 250 * tint);
    rect(xpos + superx, ypos + supery, bwidth * min(1, percentage / 100.0f), bheight);
    
    stroke(100 * tint);
    strokeWeight(2);
    strokeJoin(BEVEL);
    fill(0, 0, 0, 0);
    
    rect(xpos + superx, ypos + supery, bwidth, bheight);
    
    percentageText.display();
  }
}
class AddTaskWindow extends UI {
  final int wwidth = (int)(width * 0.55f);
  final int wheight = 170;
  final int buttonHeight = 50, buttonWidth = 120;
  final int spacing = 12;
  
  boolean open = false;
  
  Text title;
  TextButton edit;
  TextButton create;
  
  public AddTaskWindow() {
    super(0, 0);
    xpos = width/2 - wwidth/2;
    ypos = height/2 - wheight/2;
    
    title = new Text(wwidth/2, 38, "Set Title", timerFont, this);
    edit = new TextButton(wwidth/2 - (int)(wwidth * 0.45f), wheight/2 - 25, (int)(wwidth * 0.9f), 38, "", this);
    create = new TextButton(wwidth/2 - buttonWidth/2, wheight - spacing - buttonHeight, buttonWidth, buttonHeight, "CREATE", this); 
  }
  
  public void update() {
    title.update();
    //edit.update();
    
    if(open && ((create.pressed && !mousePressed) || (key == ENTER && keyPressed))) {
      tasks.tasks.add(new Task(edit.text.text, tasks));
      open = false;
      edit.text.text = "";
    }
    create.update();
  }
  
  public void pressKey() {
    if((key >= 'a' && key <= 'z') || (key >= 'A' && key <= 'Z') || (key >= '0' && key <= '9') || key == ' ' || key == BACKSPACE) {
      if(key == BACKSPACE) {
        if(edit.text.text.length() > 0)
          edit.text.text = edit.text.text.substring(0, edit.text.text.length()-1);
      } else {
        edit.text.text += key;
      }
    }
  }
  
  public void display() {
    if(open) {
      float superx = 0, supery = 0;
      if(superUI != null) {
        superx = superUI.getXPos();
        supery = superUI.getYPos();
      }
      
      stroke(40 * tint);
      strokeWeight(4);
      strokeJoin(BEVEL);
      
      fill(235 * tint);
      rect(xpos + superx, ypos + supery, wwidth, wheight);
      
      title.display();
      tint = 1.15f;
      edit.display();
      tint = 1;
      create.display();
    }
  }
}



class RightClickWindow extends UI {
  final int buttonHeight = 30, buttonWidth = 200;
  final int spacing = 12;
  
  int taskNum = -1;
  boolean open = false;
  boolean justOpened = false;
  
  int buttonsNum = 0;
  ArrayList<ArrayList<TextButton>> buttons;
  
  public RightClickWindow() {
    super(0, 0);
    
    buttons = new ArrayList<ArrayList<TextButton>>();
    
    ArrayList<TextButton> buttonList1 = new ArrayList<TextButton>();
    buttonList1.add(new TextButton(0, (buttonHeight + 1)*buttonList1.size(), buttonWidth, buttonHeight, "delete task", this));
    buttonList1.add(new TextButton(0, (buttonHeight + 1)*buttonList1.size(), buttonWidth, buttonHeight, "complete task", this));
    buttonList1.add(new TextButton(0, (buttonHeight + 1)*buttonList1.size(), buttonWidth, buttonHeight, "reset completion", this));
    
    ArrayList<TextButton> buttonList2 = new ArrayList<TextButton>();
    buttonList2.add(new TextButton(0, (buttonHeight + 1)*buttonList2.size(), buttonWidth, buttonHeight, "delete job", this));
    buttonList2.add(new TextButton(0, (buttonHeight + 1)*buttonList2.size(), buttonWidth, buttonHeight, "add time", this));
    buttonList2.add(new TextButton(0, (buttonHeight + 1)*buttonList2.size(), buttonWidth, buttonHeight, "complete job", this));
    
    ArrayList<TextButton> buttonList3 = new ArrayList<TextButton>();
    buttonList3.add(new TextButton(0, (buttonHeight + 1)*buttonList3.size(), buttonWidth, buttonHeight, "delete job", this));
    buttonList3.add(new TextButton(0, (buttonHeight + 1)*buttonList3.size(), buttonWidth, buttonHeight, "add time", this));
    buttonList3.add(new TextButton(0, (buttonHeight + 1)*buttonList3.size(), buttonWidth, buttonHeight, "uncomplete job", this));
    
    ArrayList<TextButton> buttonList4 = new ArrayList<TextButton>();
    if(working)
      buttonList4.add(new TextButton(0, (buttonHeight + 1)*buttonList4.size(), buttonWidth, buttonHeight, "stop working", this));
    buttonList4.add(new TextButton(0, (buttonHeight + 1)*buttonList4.size(), buttonWidth, buttonHeight, "add break", this));
    buttonList4.add(new TextButton(0, (buttonHeight + 1)*buttonList4.size(), buttonWidth, buttonHeight, "clear completed", this));
    buttonList4.add(new TextButton(0, (buttonHeight + 1)*buttonList4.size(), buttonWidth, buttonHeight, "clear all jobs", this));
    
    buttons.add(buttonList1);
    buttons.add(buttonList2);
    buttons.add(buttonList3);
    buttons.add(buttonList4);
    
    for(ArrayList<TextButton> list: buttons) {
      for(TextButton b: list) {
        b.text.setAlign(LEFT);
        b.text.xpos = 8;
      }
    }
  }
  
  public void open(int type, int n) {
    buttonsNum = type;
    taskNum = n;
    open = true;
    justOpened = true;
    setPosition(mouseX, mouseY);
    
    if(buttonsNum == 1 && jobs.jobs.get(taskNum).completed) {
      buttonsNum = 2;
    }
  }
  
  public void setPosition(int x, int y) {
    xpos = x;
    ypos = y;
  }
  
  public void update() {
    if(open) {
      boolean buttonPressed = false;
      
      for(TextButton b: buttons.get(buttonsNum)) {
        b.update();
        
        if(!justOpened) {
          if(b.pressed) {
            buttonPressed = true;
          }
          if(b.action) {
            if(b.text.text.equals("delete task")) {
              tasks.tasks.remove(taskNum);
            } else if(b.text.text.equals("reset completion")) {
              tasks.tasks.get(taskNum).completion.setProgress(0);
            } else if(b.text.text.equals("complete task")) {
              tasks.tasks.get(taskNum).completion.setProgress(100);
            } else if(b.text.text.equals("delete job")) {
              jobs.jobs.remove(taskNum);
            } else if(b.text.text.equals("add time")) {
              addTimeWindow.open(jobs.jobs.get(taskNum));
            } else if(b.text.text.equals("complete job")) {
              jobs.jobs.get(taskNum).completed = true;
              jobs.jobs.get(taskNum).superTask.completion.addProgress(jobs.jobs.get(taskNum).percentage * 1);
            } else if(b.text.text.equals("uncomplete job")) {
              jobs.jobs.get(taskNum).completed = false;
              jobs.jobs.get(taskNum).superTask.completion.addProgress(jobs.jobs.get(taskNum).percentage * -1);
            } else if(b.text.text.equals("clear all jobs")) {
              for(int i = jobs.jobs.size() - 1; i >= 0; i--) {
                jobs.jobs.remove(i);
              }
              working = false;
              jobs.currentJob = 0;
            } else if(b.text.text.equals("clear completed")) {
              for(int i = jobs.jobs.size() - 1; i >= 0; i--) {
                if(jobs.jobs.get(i).completed)
                  jobs.jobs.remove(i);
              }
              if(jobs.jobs.size() == 0) {
                working = false;
                jobs.currentJob = 0; 
              }
            } else if(b.text.text.equals("add break")) {
              addBreakWindow.open();
            } else if(b.text.text.equals("stop working")) {
              working = false;
              jobs.currentJob = 0; 
            }
            open = false;
            windowOpen = true;
          }
        }
      }
      
      if(!buttonPressed && mousePressed && mouseButton == LEFT && !justOpened) {
        open = false;
      }
    }
    
    justOpened = false;
  }
  
  public void display() {
    if(open) {
      for(TextButton b: buttons.get(buttonsNum)) {
        b.display();
      }
    }
  }
}



class CreateJobWindow extends UI {
  final int wwidth = (int)(width * 0.65f);
  final int wheight = 170;
  final int buttonHeight = 45, buttonWidth = 110;
  final int sbuttonHeight = 32, sbuttonWidth = 64;
  final int spacing = 12;
  
  boolean open = false;
  boolean noMaxTime = false;
  
  boolean canCreate = false;
  int taskNum = -1;
  
  int pageNum = 0;
  Text title1, title2, title3;
  int pct = 50;
  Time maxTime;
  Text percentage, maxTimeText;
  TextButton edit;
  TextButton create, next, skip;
  TextButton more, less;
  TextButton plus1, plus5, minus1, minus5;
  
  public CreateJobWindow() {
    super(0, 0);
    xpos = width/2 - wwidth/2;
    ypos = height/2 - wheight/2;
    
    title1 = new Text(wwidth/2, 38, "How much of this task?", taskFont, this);
    title2 = new Text(wwidth/2, 38, "Expected time?", taskFont, this);
    title3 = new Text(wwidth/2, 38, "Edit title?", taskFont, this);
    
    create = new TextButton(wwidth/2 - buttonWidth/2, wheight - spacing - buttonHeight, buttonWidth, buttonHeight, "CREATE", this);
    next = new TextButton(wwidth/2 - buttonWidth/2, wheight - spacing - buttonHeight, buttonWidth, buttonHeight, "NEXT", this);
    skip = new TextButton(wwidth - buttonWidth - spacing, wheight - spacing - buttonHeight, buttonWidth, buttonHeight, "SKIP", this);
    
    percentage = new Text(wwidth/2, wheight/2 - 2, "50%", taskFont, this);
    percentage.setColor(new int[] {160, 160, 250});
    more = new TextButton(wwidth/2 + 45, wheight/2 - sbuttonHeight/2 - 6, sbuttonWidth, sbuttonHeight, "more", this);
    less = new TextButton(wwidth/2 - 45 - sbuttonWidth, wheight/2 - sbuttonHeight/2 - 6, sbuttonWidth, sbuttonHeight, "less", this);
    
    maxTime = new Time(0, 10, 0);
    maxTimeText = new Text(wwidth/2, wheight/2 - 2, maxTime.toString(), taskFont, this);
    plus1 = new TextButton(wwidth/2 + 65, wheight/2 - sbuttonHeight/2 - 6, sbuttonHeight, sbuttonHeight, "+1", this);
    plus5 = new TextButton(wwidth/2 + 75 + sbuttonHeight, wheight/2 - sbuttonHeight/2 - 6, sbuttonHeight, sbuttonHeight, "+5", this);
    minus1 = new TextButton(wwidth/2 - 65 - sbuttonHeight, wheight/2 - sbuttonHeight/2 - 6, sbuttonHeight, sbuttonHeight, "-1", this);
    minus5 = new TextButton(wwidth/2 - 75 - sbuttonHeight*2, wheight/2 - sbuttonHeight/2 - 6, sbuttonHeight, sbuttonHeight, "-5", this);
    
    edit = new TextButton(wwidth/2 - (int)(wwidth * 0.45f), wheight/2 - 25, (int)(wwidth * 0.9f), 38, "", this);
  }
  
  public void open(int taskNum) {
    open = true;
    pageNum = 0;
    noMaxTime = false;
    this.taskNum = taskNum;
    
    pct = 50;
    percentage.text = "50%";
    maxTime = new Time(0, 10, 0);
    maxTimeText.text = maxTime.toString();
  }
  
  public void update() {
    if(open) {
      switch(pageNum) {
      case 0:
        title1.update();
        percentage.update();
        less.update();
        more.update();
        
        if(less.action && pct > 0) {
          pct -= 10;
          percentage.text = pct + "%";
        } else if(more.action & pct < 100) {
          pct += 10;
          percentage.text = pct + "%";
        }
        
        next.update();
        if(next.action) {
          pageNum++;
        }
        break;
      case 1:
        title2.update();
        maxTimeText.update();
        plus1.update();
        plus5.update();
        minus1.update();
        minus5.update();
        
        if(plus1.action) {
          maxTime = new Time(maxTime.totalSeconds + 60);
          maxTimeText.text = maxTime.toString();
        } else if(plus5.action) {
          maxTime = new Time(maxTime.totalSeconds + 300);
          maxTimeText.text = maxTime.toString();
        } else if(minus1.action && maxTime.totalSeconds > 60) {
          maxTime = new Time(maxTime.totalSeconds - 60);
          maxTimeText.text = maxTime.toString();
        } else if(minus5.action && maxTime.totalSeconds > 300) {
          maxTime = new Time(maxTime.totalSeconds - 300);
          maxTimeText.text = maxTime.toString();
        }
        
        next.update();
        skip.update();
        
        if(next.action) {
          pageNum++;
          autoName();
          canCreate = false;
        } else if(skip.action) {
          noMaxTime = true;
          pageNum++;
          autoName();
          canCreate = false;
        }
        break;
      case 2:
        title3.update();
        //edit.update();
  
        if(canCreate && ((create.pressed && !mousePressed) || (key == ENTER && keyPressed))) {
          if(noMaxTime)
            jobs.jobs.add(new Job(edit.text.text, null, pct, tasks.tasks.get(taskNum), jobs));
          else
            jobs.jobs.add(new Job(edit.text.text, maxTime, pct, tasks.tasks.get(taskNum), jobs));
          open = false;
          edit.text.text = "";
        }
        create.update();
        
        if(!mousePressed)
          canCreate = true;
        break;
      }
    }
        
        /*if((create.pressed && !mousePressed) || (key == ENTER && keyPressed)) {
          tasks.tasks.add(new Task(edit.text.text, tasks));
          open = false;
          edit.text.text = "";
        }*/
  }
  
  private void autoName() {
    String name = "";
    /*if(pct == 50) {
      name += "half";
    } else {
      name += pct + "%";
    }
    
    name += " of " + tasks.tasks.get(taskNum).title;*/
    name += tasks.tasks.get(taskNum).title;
    edit.text.text = name;
  }
  
  public void pressKey() {
    if(pageNum == 2 && open) {
      if((key >= 'a' && key <= 'z') || (key >= 'A' && key <= 'Z') || (key >= '0' && key <= '9') || key == ' ' || key == BACKSPACE) {
        if(key == BACKSPACE) {
          if(edit.text.text.length() > 0)
            edit.text.text = edit.text.text.substring(0, edit.text.text.length()-1);
        } else {
          edit.text.text += key;
        }
      }
    }
  }
  
  public void display() {
    if(open) {
      float superx = 0, supery = 0;
      if(superUI != null) {
        superx = superUI.getXPos();
        supery = superUI.getYPos();
      }
      
      stroke(40 * tint);
      strokeWeight(4);
      strokeJoin(BEVEL);
      
      fill(235 * tint);
      rect(xpos + superx, ypos + supery, wwidth, wheight);
      
      switch(pageNum) {
      case 0:
        title1.display();
        percentage.display();
        less.display();
        more.display();
        next.display();
        break;
      case 1:
        title2.display();
        maxTimeText.display();
        plus1.display();
        plus5.display();
        minus1.display();
        minus5.display();
        next.display();
        skip.display();
        break;
      case 2:
        title3.display();
        tint = 1.15f;
        edit.display();
        tint = 1;
        create.display();
        break;
      }
    }
  }
}



class AddTimeWindow extends UI {
  final int wwidth = (int)(width * 0.55f);
  final int wheight = 170;
  final int buttonHeight = 50, buttonWidth = 120;
  final int sbuttonHeight = 32, sbuttonWidth = 64;
  final int spacing = 12;
  
  boolean open = false;
  
  Text title;
  TextButton create, plus1, plus5, minus1, minus5;
  Text addTimeText;
  Time addTime;
  
  Job currentJob;
  
  public AddTimeWindow() {
    super(0, 0);
    xpos = width/2 - wwidth/2;
    ypos = height/2 - wheight/2;
    
    title = new Text(wwidth/2, 38, "Add how much?", timerFont, this);
    create = new TextButton(wwidth/2 - buttonWidth/2, wheight - spacing - buttonHeight, buttonWidth, buttonHeight, "ADD", this); 
    
    addTime = new Time(0, 0, 0);
    addTimeText = new Text(wwidth/2, wheight/2 - 2, addTime.toString(), taskFont, this);
    plus1 = new TextButton(wwidth/2 + 65, wheight/2 - sbuttonHeight/2 - 6, sbuttonHeight, sbuttonHeight, "+1", this);
    plus5 = new TextButton(wwidth/2 + 75 + sbuttonHeight, wheight/2 - sbuttonHeight/2 - 6, sbuttonHeight, sbuttonHeight, "+5", this);
    minus1 = new TextButton(wwidth/2 - 65 - sbuttonHeight, wheight/2 - sbuttonHeight/2 - 6, sbuttonHeight, sbuttonHeight, "-1", this);
    minus5 = new TextButton(wwidth/2 - 75 - sbuttonHeight*2, wheight/2 - sbuttonHeight/2 - 6, sbuttonHeight, sbuttonHeight, "-5", this);
  }
  
  public void open(Job j) {
    open = true;
    currentJob = j;
  }
  
  public void update() {
    if(open) {
      title.update();
      //edit.update();
      
      if((create.pressed && !mousePressed) || (key == ENTER && keyPressed)) {
        //tasks.tasks.add(new Task(edit.text.text, tasks));
        open = false;
        currentJob.maxTime.t = new Time(currentJob.maxTime.t.totalSeconds + addTime.totalSeconds);
        timer.active = true;
        pause.text.text = "pause";
      }
      create.update();
      
      plus1.update();
      plus5.update();
      minus1.update();
      minus5.update();
      
      if(plus1.action) {
        addTime = new Time(addTime.totalSeconds + 60);
      } else if(plus5.action) {
        addTime = new Time(addTime.totalSeconds + 300);
      } else if(minus1.action) {
        if(addTime.totalSeconds > 60)
          addTime = new Time(addTime.totalSeconds - 60);
      } else if(minus5.action) {
        if(addTime.totalSeconds > 3600)
          addTime = new Time(addTime.totalSeconds - 300);
      }
      addTimeText.text = addTime.toString();
    }
  }
  
  public void display() {
    if(open) {
      float superx = 0, supery = 0;
      if(superUI != null) {
        superx = superUI.getXPos();
        supery = superUI.getYPos();
      }
      
      stroke(40 * tint);
      strokeWeight(4);
      strokeJoin(BEVEL);
      
      fill(235 * tint);
      rect(xpos + superx, ypos + supery, wwidth, wheight);
      
      title.display();
      create.display();
      plus1.display();
      plus5.display();
      minus1.display();
      minus5.display();
      addTimeText.display();
    }
  }
}




class AddBreakWindow extends UI {
  final int wwidth = (int)(width * 0.65f);
  final int wheight = 170;
  final int buttonHeight = 45, buttonWidth = 110;
  final int sbuttonHeight = 32, sbuttonWidth = 64;
  final int spacing = 12;
  
  boolean open = false;
  
  boolean canCreate = false;
  
  Text title;
  Time maxTime;
  Text maxTimeText;
  TextButton create, skip;
  TextButton plus1, plus5, minus1, minus5;
  
  public AddBreakWindow() {
    super(0, 0);
    xpos = width/2 - wwidth/2;
    ypos = height/2 - wheight/2;
    
    title = new Text(wwidth/2, 38, "Break how long?", taskFont, this);
    
    create = new TextButton(wwidth/2 - buttonWidth/2, wheight - spacing - buttonHeight, buttonWidth, buttonHeight, "CREATE", this);
    skip = new TextButton(wwidth - buttonWidth - spacing, wheight - spacing - buttonHeight, buttonWidth, buttonHeight, "SKIP", this);
    
    maxTime = new Time(0, 10, 0);
    maxTimeText = new Text(wwidth/2, wheight/2 - 2, maxTime.toString(), taskFont, this);
    plus1 = new TextButton(wwidth/2 + 65, wheight/2 - sbuttonHeight/2 - 6, sbuttonHeight, sbuttonHeight, "+1", this);
    plus5 = new TextButton(wwidth/2 + 75 + sbuttonHeight, wheight/2 - sbuttonHeight/2 - 6, sbuttonHeight, sbuttonHeight, "+5", this);
    minus1 = new TextButton(wwidth/2 - 65 - sbuttonHeight, wheight/2 - sbuttonHeight/2 - 6, sbuttonHeight, sbuttonHeight, "-1", this);
    minus5 = new TextButton(wwidth/2 - 75 - sbuttonHeight*2, wheight/2 - sbuttonHeight/2 - 6, sbuttonHeight, sbuttonHeight, "-5", this);
  }
  
  public void open() {
    open = true;
    
    maxTime = new Time(0, 10, 0);
    maxTimeText.text = maxTime.toString();
  }
  
  public void update() {
    if(open) {
      title.update();
      maxTimeText.update();
      plus1.update();
      plus5.update();
      minus1.update();
      minus5.update();
      
      if(plus1.action) {
        maxTime = new Time(maxTime.totalSeconds + 60);
        maxTimeText.text = maxTime.toString();
      } else if(plus5.action) {
        maxTime = new Time(maxTime.totalSeconds + 300);
        maxTimeText.text = maxTime.toString();
      } else if(minus1.action && maxTime.totalSeconds > 60) {
        maxTime = new Time(maxTime.totalSeconds - 60);
        maxTimeText.text = maxTime.toString();
      } else if(minus5.action && maxTime.totalSeconds > 300) {
        maxTime = new Time(maxTime.totalSeconds - 300);
        maxTimeText.text = maxTime.toString();
      }
      
      skip.update();

      if(canCreate && ((create.pressed && !mousePressed) || (key == ENTER && keyPressed))) {
        jobs.jobs.add(new Break(maxTime, jobs));
        open = false;
      } else if(skip.action) {
        jobs.jobs.add(new Break(null, jobs));
        open = false;
      }
      create.update();
      
      if(!mousePressed)
        canCreate = true;
    }
        
        /*if((create.pressed && !mousePressed) || (key == ENTER && keyPressed)) {
          tasks.tasks.add(new Task(edit.text.text, tasks));
          open = false;
          edit.text.text = "";
        }*/
  }
  
  public void display() {
    if(open) {
      float superx = 0, supery = 0;
      if(superUI != null) {
        superx = superUI.getXPos();
        supery = superUI.getYPos();
      }
      
      stroke(40 * tint);
      strokeWeight(4);
      strokeJoin(BEVEL);
      
      fill(235 * tint);
      rect(xpos + superx, ypos + supery, wwidth, wheight);
      
      title.display();
      maxTimeText.display();
      plus1.display();
      plus5.display();
      minus1.display();
      minus5.display();
      create.display();
      skip.display();
    }
  }
}
class Job extends UI {
  float moveSpeed = 0.1f;
  
  float targetx, targety;
  String title;
  Text titleText;
  Timer maxTime;
  //Button complete, addTime, pause;
  Button background;
  
  int percentage;
  
  boolean hasMaxTime = true;
  boolean completed = false;
  boolean active = false;
  
  Task superTask;
  
  UI[] elements;
  
  public Job(String t, Time max, int pct, Task superTask, UI superUI) {
    super(0, 0);
    
    title = t;
    this.superUI = superUI;
    this.superTask = superTask;
    percentage = pct;
    
    background = new Button(0, 0, taskWidth, taskHeight, this);
    
    titleText = new Text(taskWidth/2, 5, title, taskFont, this);
    titleText.setAlign(CENTER, TOP);
    
    Text inText = null;
    Text pctText = new Text(10, taskHeight - 17, pct + "%", timerFont, this);
    pctText.setAlign(LEFT);
    if(max == null) {
      hasMaxTime = false;
    } else {
      maxTime = new Timer(taskWidth - 10, taskHeight - 17, false, max, this);
      maxTime.align = RIGHT;
      inText = new Text(taskWidth/2 - 4, taskHeight - 21, "in", buttonFont, this);
    }
    
    /*
    int buttonHeight = 25, buttonWidth = 120;
    complete = new TextButton(taskWidth - buttonWidt, h - 10, taskHeight - 10 - buttonHeight*1, buttonWidth, buttonHeight, "Complete", this);
    addTime = new TextButton(taskWidth - buttonWidth - 10, taskHeight - 15 - buttonHeight*2, buttonWidth, buttonHeight, "Add Time", this);
    pause = new TextButton(taskWidth - buttonWidth - 10, taskHeight - 20 - buttonHeight*3, buttonWidth, buttonHeight, "Pause", this);*/
    
    if(hasMaxTime)
      elements = new UI[] {titleText, maxTime, inText, pctText};
    else
      elements = new UI[] {titleText, pctText};
  }
  
  public void setTargetPosition(float x, float y) {
    targetx = x;
    targety = y;
  }
  
  public void snapToPosition() {
    xpos = targetx;
    ypos = targety;
  }
  
  public void update() {
    xpos += (targetx - xpos) * moveSpeed;
    ypos += (targety - ypos) * moveSpeed;
    
    background.update();
    for(UI element: elements) {
      element.update();
    }
    
    /*if(completion.percentage == 100) {
      completed = true;
    } else {
      completed = false;
    }*/
  }
  
  public void display() {
    float superx = 0, supery = 0;
    if(superUI != null) {
      superx = superUI.getXPos();
      supery = superUI.getYPos();
    }
    
    float prevTint = tint;
    if(completed) {
      tint *= 0.6f;
    }
    if(!active) {
      tint *= 0.75f;
    }
    
    background.display();
    
    stroke(40 * tint);
    strokeWeight(4);
    strokeJoin(BEVEL);
    
    fill(235 * tint);
    rect(xpos + superx, ypos + supery, taskWidth, taskHeight);
    
    for(UI element: elements) {
      element.display();
    }
    
    tint = prevTint;
  }
}

class Break extends Job {
  public Break(Time max, UI superUI) {
    super("break", max, 0,  new Task("", null), superUI);
    
    if(hasMaxTime) {
      maxTime = new Timer(taskWidth / 2, taskHeight - 22, false, max, this);
      maxTime.align = CENTER;
      elements = new UI[] {titleText, maxTime};
    } else {
      titleText = new Text(taskWidth/2, 26, title, taskFont, this);
      titleText.setAlign(CENTER, TOP);
      elements = new UI[] {titleText};
    }
  }
}



class JobList extends UI {
  ArrayList<Job> jobs;
  String title;
  float scrollAmount;
  
  float targetx, targety;
  float moveSpeed = 0.2f;
  
  int selectedTask = -1;
  int currentJob = 0;
  
  public JobList(String title, UI superUI) {
    super(0, 0);
    
    this.title = title;
    this.superUI = superUI;
    
    jobs = new ArrayList<Job>();
    
    
    updateTasks();
  }
  
  public void updateTasks() {
    for(int i = 0; i < jobs.size(); i++) {
      if(i != selectedTask) {
        Job t = jobs.get(i);
      
        t.setTargetPosition(0, i * (taskHeight + taskSpacing) + taskBorder);
        t.snapToPosition();
      }
    }
  }
  
  public void setTargetPosition(float x, float y) {
    targetx = x;
    targety = y;
  }
  
  public void snapToPosition() {
    xpos = targetx;
    ypos = targety;
  }
  
  public void beginWork() {
    currentJob = 0;
    while(currentJob < jobs.size() && jobs.get(currentJob).completed) {
      currentJob++;
    }
    if(currentJob == jobs.size()) {
      currentJob = 0;
      working = false;
    }
  }
  
  public void nextJob() {
    if(!jobs.get(currentJob).completed) {
      jobs.get(currentJob).superTask.completion.addProgress(jobs.get(currentJob).percentage);
      jobs.get(currentJob).completed = true;
    }
    
    timer.active = true;
    timer.t = new Time(0, 0, 0);
    
    if(currentJob < jobs.size() - 1) {
      currentJob++;
      
      if(jobs.get(currentJob).completed) {
        nextJob();
      }
    } else {
      currentJob = 0;
      working = false;
    }
  }
  
  public void update() {
    if(working) {
      targety = -bar2.scrollValue * max(0, 0 + 0 + jobs.size() * (taskHeight + taskSpacing) + taskBorder*2 - taskSpacing - jobScreenHeight);
    } else {
      targety = -bar2.scrollValue * max(0, 0 + 0 + jobs.size() * (taskHeight + taskSpacing) + taskBorder*2 - taskSpacing - jobScreenHeight);
    }
    
    xpos += (targetx - xpos) * moveSpeed;
    ypos += (targety - ypos) * moveSpeed;
    
    if(working) {
      for(int i = 0; i < jobs.size(); i++) {
        Job t = jobs.get(i);
        
        t.setTargetPosition(0, i * (taskHeight + taskSpacing) + taskBorder);
        
        if(t.background.action && selectedTask == -1 && !windowOpen && !prevWindowOpen) {
          if(mouseButton == LEFT) {
            //selectedTask = i;
          } else {
            //rightClickWindow.open(1, i);
          }
        }
        
        if(i == currentJob) {
          t.active = true;
          
          if(jobs.get(i).hasMaxTime) {
            maxTime.text = jobs.get(i).maxTime.t.toString();
          } else {
            maxTime.text = "Unlimited";
          }
        } else {
          t.active = false;
        }
      }
      
      jobListTitle.text = jobs.get(currentJob).title;
      
      if(timer.active && jobs.get(currentJob).hasMaxTime && timer.t.totalSeconds >= jobs.get(currentJob).maxTime.t.totalSeconds) {
        timer.active = false;
        pause.text.text = "add";
        alarm.play();
      }
    } else {
      jobListTitle.text = "Workflow";
      for(int i = 0; i < jobs.size(); i++) {
        Job t = jobs.get(i);
        
        t.setTargetPosition(0, i * (taskHeight + taskSpacing) + taskBorder);
        t.active = true;
        
        if(t.background.action && selectedTask == -1 && !windowOpen && !prevWindowOpen) {
          if(mouseButton == LEFT) {
            selectedTask = i;
          } else {
            rightClickWindow.open(1, i);
          }
        }
      }
      
      if(selectedTask != -1 && !(mousePressed && mouseButton == LEFT)) {
        selectedTask = -1;
      } else if(selectedTask != -1 && (mousePressed && mouseButton == LEFT)) {
        float distance = mouseY - taskHeight/2 - ypos - (selectedTask * (taskHeight + taskSpacing) + taskBorder + topBarHeightR);
        
        if(distance > taskHeight/2 + taskSpacing && selectedTask < jobs.size()-1) {
          jobs.add(selectedTask + 1, jobs.remove(selectedTask));
          selectedTask++;
          distance -= taskHeight + taskSpacing;
        }
        
        if(distance < -taskHeight/2 - taskSpacing && selectedTask > 0) {
          jobs.add(selectedTask - 1, jobs.remove(selectedTask));
          selectedTask--;
          distance += taskHeight + taskSpacing;
        }
        
        jobs.get(selectedTask).targety = (selectedTask * (taskHeight + taskSpacing) + taskBorder) + distance;
        jobs.get(selectedTask).snapToPosition();
      }
    }
    
    for(int i = 0; i < jobs.size(); i++) {
      Job t = jobs.get(i);
      
      if(i == selectedTask) {
        t.moveSpeed = 0.3f;
      } else {
        t.moveSpeed = 0.2f;
      }
      
      t.update();
    }
  }
  
  public void display() {
    for(int i = 0; i < jobs.size(); i++) {
      Job t = jobs.get(i);
      
      if(i != selectedTask) {
        t.display();
      }
    }
    if(selectedTask != -1) {
      jobs.get(selectedTask).display();
    }
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "work_plan_thing" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
